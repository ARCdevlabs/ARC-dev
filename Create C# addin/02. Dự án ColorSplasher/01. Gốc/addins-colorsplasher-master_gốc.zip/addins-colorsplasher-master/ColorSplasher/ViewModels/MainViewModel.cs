﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ColorSplasher.Annotations;
using System.ComponentModel;
using System.Windows;
using System.Runtime.CompilerServices;
using System.Reflection;
using System.Diagnostics;
using ColorSplasher.Common;
using Autodesk.Revit.DB;

namespace ColorSplasher.ViewModels
{
    class MainViewModel
    {
        public MainViewModel()
        {
        }

    }
}
